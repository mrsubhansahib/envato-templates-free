

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.shared/page-title', ['sub_title' => 'Charts', 'page_title' => '404 Alt Error'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="row justify-content-center items">
        <div class="col-12">
            <div class="d-flex flex-column h-100">
                <div class="row justify-content-center">
                    <div class="col-lg-4">
                        <div class="text-center">
                            <h1 class="text-error mb-4">404</h1>
                            <h2 class="text-uppercase text-danger mt-3">Page Not Found</h2>
                            <p class="text-muted mt-3">It's looking like you may have taken a wrong turn. Don't worry... it
                                happens to the best of us. Here's a
                                little tip that might help you get back on track.</p>

                            <a class="btn btn-soft-danger mt-3" href="<?php echo e(route('any', 'index')); ?>"><i
                                    class="ri-home-4-line me-1"></i> Back to Home</a>
                        </div> <!-- end /.text-center-->
                    </div> <!-- end col-->
                </div>
            </div>
        </div> <!-- end col -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.vertical', ['title' => 'Error 404 Alt', 'mode' => $mode ?? '', 'demo' => $demo ?? ''], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ct9/Desktop/Ishan/velonic/velonic_laravel/velonic/resources/views/error/404-alt.blade.php ENDPATH**/ ?>