<meta charset="utf-8" />
<title><?php echo e($title); ?> | Velonic - Bootstrap 5 Admin & Dashboard Template</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta content="A fully responsive admin theme which can be used to build CRM, CMS,ERP etc." name="description" />
<meta content="Techzaa" name="author" />

<!-- App favicon -->
<link rel="shortcut icon" href="/images/favicon.ico"><?php /**PATH /home/ct9/Desktop/Ishan/velonic/velonic_laravel/velonic/resources/views/layouts/shared/title-meta.blade.php ENDPATH**/ ?>