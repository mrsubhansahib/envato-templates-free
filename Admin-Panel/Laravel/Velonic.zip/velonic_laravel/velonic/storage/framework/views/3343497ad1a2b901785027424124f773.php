<!-- bundle -->
<?php echo $__env->yieldContent('script'); ?>
<!-- App js -->
<?php echo $__env->yieldContent('script-bottom'); ?><?php /**PATH /home/ct9/Desktop/Ishan/velonic/velonic_laravel/velonic/resources/views/layouts/shared/footer-scripts.blade.php ENDPATH**/ ?>