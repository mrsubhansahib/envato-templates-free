<!-- bundle -->
@yield('script')
<!-- App js -->
@yield('script-bottom')