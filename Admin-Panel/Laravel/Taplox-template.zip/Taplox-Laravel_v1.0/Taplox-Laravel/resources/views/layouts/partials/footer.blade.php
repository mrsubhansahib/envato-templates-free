<footer class="footer card mb-0 rounded-0 justify-content-center align-items-center">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12 text-center">
                <p class="mb-0">
                    <script>
                        document.write(new Date().getFullYear())
                    </script> &copy; Taplox.</a>
                </p>
            </div>
        </div>
    </div>
</footer>