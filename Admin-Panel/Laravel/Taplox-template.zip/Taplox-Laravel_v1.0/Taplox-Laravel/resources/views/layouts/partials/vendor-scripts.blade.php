@vite('resources/js/app.js')

@yield('scripts')