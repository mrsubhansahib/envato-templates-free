<?php $__env->startSection('parentPageTitle', 'App'); ?>
<?php $__env->startSection('title', 'Tickets'); ?>


<?php $__env->startSection('content'); ?>
<div class="row clearfix">
    <div class="col-lg-3 col-md-6">
        <div class="card">
            <div class="body text-center">
                <div class="sparkline-pie">5,3,2</div>
                <h3 class="m-b-0 m-t-10">2078</h3>
                <span >Total Tickets</span>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-6">
        <div class="card">
            <div class="body text-center">
                <input type="text" class="knob2" value="50" data-width="90" data-height="90" data-thickness="0.15"  data-fgColor="#00ca70">
                <h3 class="m-b-0 m-t-10">1278</h3>
                <span>Resolve</span>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-6">
        <div class="card">
            <div class="body text-center">
                <input type="text" class="knob2" value="30" data-width="90" data-height="90" data-thickness="0.15"  data-fgColor="#4b78b8">
                <h3 class="m-b-0 m-t-10">521</h3>
                <span>Pending</span>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-6">
        <div class="card">
            <div class="body text-center">
                <input type="text" class="knob2" value="20" data-width="90" data-height="90" data-thickness="0.15"  data-fgColor="#ffbf00">
                <h3 class="m-b-0 m-t-10">978</h3>
                <span>Responded</span>
            </div>
        </div>
    </div>
</div>
<div class="row clearfix">
    <div class="col-lg-12 col-md-12">
        <div class="card">
            <div class="header">
                <h2>Support & Ticket List</h2>
                <ul class="header-dropdown">
                    <li><a class="tab_btn" href="javascript:void(0);" data-toggle="tooltip" data-placement="top" title="Weekly">W</a></li>
                    <li><a class="tab_btn" href="javascript:void(0);" data-toggle="tooltip" data-placement="top" title="Monthly">M</a></li>
                    <li><a class="tab_btn active" href="javascript:void(0);" data-toggle="tooltip" data-placement="top" title="Yearly">Y</a></li>
                    <li class="dropdown">
                        <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"></a>
                        <ul class="dropdown-menu dropdown-menu-right animated bounceIn">
                            <li><a href="javascript:void(0);">Action</a></li>
                            <li><a href="javascript:void(0);">Another Action</a></li>
                            <li><a href="javascript:void(0);">Something else</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
            <div class="body">
                <div class="table-responsive">
                    <table class="table table-hover js-basic-example dataTable table-custom m-b-0">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Assign By</th>
                                <th>Assign to</th>
                                <th>Email</th>
                                <th>Subjects</th>
                                <th>Status</th>
                                <th>Date</th>
                                <th>Action</th>
                            </tr>
                        </thead>                                
                        <tbody>
                            <tr>
                                <td>231</td>
                                <td>Airi Satou</td>
                                <td>Angelica Ramos</td>
                                <td>airi@example.com</td>
                                <td>New Code Update</td>
                                <td><span class="badge badge-default">Pending</span></td>
                                <td>24-04-2018</td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-outline-secondary" title="Edit"><i class="fa fa-edit"></i></button>
                                    <button type="button" class="btn btn-sm btn-outline-danger js-sweetalert" title="Delete" data-type="confirm"><i class="fa fa-trash-o"></i></button>
                                </td>
                            </tr>
                            <tr>
                                <td>235</td>
                                <td>Brenden Wagner</td>
                                <td>Ashton Cox</td>
                                <td>airi@example.com</td>
                                <td>New Code Update</td>
                                <td><span class="badge badge-success">Complete</span></td>
                                <td>24-04-2018</td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-outline-secondary" title="Edit"><i class="fa fa-edit"></i></button>
                                    <button type="button" class="btn btn-sm btn-outline-danger js-sweetalert" title="Delete" data-type="confirm"><i class="fa fa-trash-o"></i></button>
                                </td>
                            </tr>
                            <tr>
                                <td>236</td>
                                <td>Bradley Greer</td>
                                <td>Cara Stevens</td>
                                <td>airi@example.com</td>
                                <td>New Code Update</td>
                                <td><span class="badge badge-success">Complete</span></td>
                                <td>24-04-2018</td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-outline-secondary" title="Edit"><i class="fa fa-edit"></i></button>
                                    <button type="button" class="btn btn-sm btn-outline-danger js-sweetalert" title="Delete" data-type="confirm"><i class="fa fa-trash-o"></i></button>
                                </td>
                            </tr>
                            <tr>
                                <td>245</td>
                                <td>Cara Stevens</td>
                                <td>Airi Satou</td>
                                <td>airi@example.com</td>
                                <td>New Code Update</td>
                                <td><span class="badge badge-default">Pending</span></td>
                                <td>24-04-2018</td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-outline-secondary" title="Edit"><i class="fa fa-edit"></i></button>
                                    <button type="button" class="btn btn-sm btn-outline-danger js-sweetalert" title="Delete" data-type="confirm"><i class="fa fa-trash-o"></i></button>
                                </td>
                            </tr>
                            <tr>
                                <td>248</td>
                                <td>Airi Satou</td>
                                <td>Angelica Ramos</td>
                                <td>airi@example.com</td>
                                <td>New Code Update</td>
                                <td><span class="badge badge-success">Complete</span></td>
                                <td>24-04-2018</td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-outline-secondary" title="Edit"><i class="fa fa-edit"></i></button>
                                    <button type="button" class="btn btn-sm btn-outline-danger js-sweetalert" title="Delete" data-type="confirm"><i class="fa fa-trash-o"></i></button>
                                </td>
                            </tr>
                            <tr>
                                <td>250</td>
                                <td>Jenette Caldwell</td>
                                <td>Hermione Butler</td>
                                <td>airi@example.com</td>
                                <td>New Code Update</td>
                                <td><span class="badge badge-warning">New</span></td>
                                <td>24-04-2018</td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-outline-secondary" title="Edit"><i class="fa fa-edit"></i></button>
                                    <button type="button" class="btn btn-sm btn-outline-danger js-sweetalert" title="Delete" data-type="confirm"><i class="fa fa-trash-o"></i></button>
                                </td>
                            </tr>
                            <tr>
                                <td>260</td>
                                <td>Paul Byrd</td>
                                <td>Michael Bruce</td>
                                <td>airi@example.com</td>
                                <td>New Code Update</td>
                                <td><span class="badge badge-warning">New</span></td>
                                <td>24-04-2018</td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-outline-secondary" title="Edit"><i class="fa fa-edit"></i></button>
                                    <button type="button" class="btn btn-sm btn-outline-danger js-sweetalert" title="Delete" data-type="confirm"><i class="fa fa-trash-o"></i></button>
                                </td>
                            </tr>
                            <tr>
                                <td>261</td>
                                <td>Lael Greer</td>
                                <td>Martena Mccray</td>
                                <td>airi@example.com</td>
                                <td>New Code Update</td>
                                <td><span class="badge badge-warning">New</span></td>
                                <td>24-04-2018</td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-outline-secondary" title="Edit"><i class="fa fa-edit"></i></button>
                                    <button type="button" class="btn btn-sm btn-outline-danger js-sweetalert" title="Delete" data-type="confirm"><i class="fa fa-trash-o"></i></button>
                                </td>
                            </tr>
                            <tr>
                                <td>262</td>
                                <td>Airi Satou</td>
                                <td>Angelica Ramos</td>
                                <td>airi@example.com</td>
                                <td>New Code Update</td>
                                <td><span class="badge badge-warning">New</span></td>
                                <td>24-04-2018</td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-outline-secondary" title="Edit"><i class="fa fa-edit"></i></button>
                                    <button type="button" class="btn btn-sm btn-outline-danger js-sweetalert" title="Delete" data-type="confirm"><i class="fa fa-trash-o"></i></button>
                                </td>
                            </tr>
                            <tr>
                                <td>278</td>
                                <td>Airi Satou</td>
                                <td>Angelica Ramos</td>
                                <td>airi@example.com</td>
                                <td>New Code Update</td>
                                <td><span class="badge badge-default">Pending</span></td>
                                <td>24-04-2018</td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-outline-secondary" title="Edit"><i class="fa fa-edit"></i></button>
                                    <button type="button" class="btn btn-sm btn-outline-danger js-sweetalert" title="Delete" data-type="confirm"><i class="fa fa-trash-o"></i></button>
                                </td>
                            </tr>
                            <tr>
                                <td>278</td>
                                <td>Airi Satou</td>
                                <td>Angelica Ramos</td>
                                <td>airi@example.com</td>
                                <td>New Code Update</td>
                                <td><span class="badge badge-default">Pending</span></td>
                                <td>24-04-2018</td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-outline-secondary" title="Edit"><i class="fa fa-edit"></i></button>
                                    <button type="button" class="btn btn-sm btn-outline-danger js-sweetalert" title="Delete" data-type="confirm"><i class="fa fa-trash-o"></i></button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Add New Task -->
<div class="modal fade" id="addcontact" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h6 class="title" id="defaultModalLabel">Add New Task</h6>
            </div>
            <div class="modal-body">
                <div class="row clearfix">
                    <div class="col-12">
                        <div class="form-group">                                    
                            <input type="text" class="form-control" placeholder="Task no.">
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="form-group">                                   
                            <input type="text" class="form-control" placeholder="Job title">
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="form-group">                                    
                            <textarea class="form-control" placeholder="Description"></textarea>
                        </div>
                    </div>
                    <div class="col-12">
                        <select class="form-control show-tick m-b-10">
                            <option>Select Team</option>
                            <option>John Smith</option>
                            <option>Hossein Shams</option>
                            <option>Maryam Amiri</option>
                            <option>Tim Hank</option>
                            <option>Gary Camara</option>
                        </select>
                    </div>
                    <div class="col-12">
                        <label>Range</label>
                        <div class="input-daterange input-group" data-provide="datepicker">
                            <input type="text" class="form-control" name="start">
                            <span class="input-group-addon"> to </span>
                            <input type="text" class="form-control" name="end">
                        </div>
                    </div>                    
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary">Add</button>
                <button type="button" class="btn btn-secondary" data-dismiss="modal">CLOSE</button>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>
<script src="<?php echo e(asset('assets/bundles/knob.bundle.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/sweetalert/sweetalert.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/bundles/datatablescripts.bundle.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/pages/tables/jquery-datatable.js')); ?>"></script>

<script src="<?php echo e(asset('assets/bundles/mainscripts.bundle.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/pages/ui/dialogs.js')); ?>"></script>

<script>
    $('.knob2').knob({
        'format' : function (value) {
            return value + '%';
         }
    });

    $('.sparkline-pie').sparkline('html', {
        type: 'pie',
        offset: 90,
        width: '100px',
        height: '100px',
        sliceColors: ['#00ca70', '#4b78b8', '#ffbf00']
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>