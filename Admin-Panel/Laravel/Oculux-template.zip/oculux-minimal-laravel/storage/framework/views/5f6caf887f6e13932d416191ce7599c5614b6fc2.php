<?php $__env->startSection('parentPageTitle', 'Clients'); ?>
<?php $__env->startSection('title', 'List'); ?>


<?php $__env->startSection('content'); ?>
<div class="row clearfix">
    <div class="col-lg-3 col-md-6 col-sm-12">
        <div class="card">
            <div class="body text-center">
                <div class="chart easy-pie-chart-1" data-percent="75"> <span><img src="../assets/images/sm/avatar1.jpg" alt="user" class="rounded-circle"/></span> </div>
                <h5>John Smith</h5>
                <small>CEO</small>
                <h6>vPro Infoweb LLC.</h6>
                <div class="m-t-15">
                    <button class="btn btn-sm btn-primary">View Profile</button>
                    <button class="btn btn-sm btn-success">Message</button>
                </div>
                <ul class="social-links list-unstyled">
                    <li><a title="facebook"href="javascript:void(0);"><i class="fa fa-facebook"></i></a></li>
                    <li><a title="twitter"href="javascript:void(0);"><i class="fa fa-twitter"></i></a></li>
                    <li><a title="instagram"href="javascript:void(0);"><i class="fa fa-instagram"></i></a></li>
                </ul>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-6 col-sm-12">
        <div class="card">
            <div class="body text-center">
                <div class="chart easy-pie-chart-1" data-percent="67"> <span><img src="../assets/images/sm/avatar2.jpg" alt="user" class="rounded-circle"/></span> </div>
                <h5>Hossein Shams</h5>
                <small>CEO</small>
                <h6>BT Technology</h6>
                <div class="m-t-15">
                    <button class="btn btn-sm btn-primary">View Profile</button>
                    <button class="btn btn-sm btn-success">Message</button>
                </div>
                <ul class="social-links list-unstyled">
                    <li><a title="google-plus"href="javascript:void(0);"><i class="fa fa-google-plus-box"></i></a></li>
                    <li><a title="twitter"href="javascript:void(0);"><i class="fa fa-twitter"></i></a></li>
                    <li><a title="linkedin"href="javascript:void(0);"><i class="fa fa-linkedin-box"></i></a></li>
                </ul>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-6 col-sm-12">
        <div class="card">
            <div class="body text-center">
                <div class="chart easy-pie-chart-1" data-percent="23"> <span><img src="../assets/images/sm/avatar3.jpg" alt="user" class="rounded-circle"/></span> </div>
                <h5>Maryam Amiri</h5>
                <small>CEO</small>
                <h6>Core Infoweb Pvt.</h6>
                <div class="m-t-15">
                    <button class="btn btn-sm btn-primary">View Profile</button>
                    <button class="btn btn-sm btn-success">Message</button>
                </div>
                <ul class="social-links list-unstyled">
                    <li><a title="facebook"href="javascript:void(0);"><i class="fa fa-facebook"></i></a></li>
                    <li><a title="twitter"href="javascript:void(0);"><i class="fa fa-twitter"></i></a></li>
                    <li><a title="instagram"href="javascript:void(0);"><i class="fa fa-instagram"></i></a></li>
                </ul>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-6 col-sm-12">
        <div class="card">
            <div class="body text-center">
                <div class="chart easy-pie-chart-1" data-percent="49"> <span><img src="../assets/images/sm/avatar4.jpg" alt="user" class="rounded-circle"/></span> </div>
                <h5>Tim Hank</h5>
                <small>CEO</small>
                <h6>AUR Tech LLC.</h6>
                <div class="m-t-15">
                    <button class="btn btn-sm btn-primary">View Profile</button>
                    <button class="btn btn-sm btn-success">Message</button>
                </div>
                <ul class="social-links list-unstyled">
                    <li><a title="linkedin"href="javascript:void(0);"><i class="fa fa-linkedin-box"></i></a></li>
                    <li><a title="twitter"href="javascript:void(0);"><i class="fa fa-twitter"></i></a></li>
                    <li><a title="instagram"href="javascript:void(0);"><i class="fa fa-instagram"></i></a></li>
                </ul>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-6 col-sm-12">
        <div class="card">
            <div class="body text-center">
                <div class="chart easy-pie-chart-1" data-percent="75"> <span><img src="../assets/images/sm/avatar5.jpg" alt="user" class="rounded-circle"/></span> </div>
                <h5>John Smith</h5>
                <small>Manager</small>
                <h6>puffintheme Pvt.</h6>
                <div class="m-t-15">
                    <button class="btn btn-sm btn-primary">View Profile</button>
                    <button class="btn btn-sm btn-success">Message</button>
                </div>
                <ul class="social-links list-unstyled">
                    <li><a title="facebook"href="javascript:void(0);"><i class="fa fa-facebook"></i></a></li>
                    <li><a title="twitter"href="javascript:void(0);"><i class="fa fa-twitter"></i></a></li>
                    <li><a title="instagram"href="javascript:void(0);"><i class="fa fa-instagram"></i></a></li>
                </ul>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-6 col-sm-12">
        <div class="card">
            <div class="body text-center">
                <div class="chart easy-pie-chart-1" data-percent="88"> <span><img src="../assets/images/sm/avatar1.jpg" alt="user" class="rounded-circle"/></span> </div>
                <h5>Frank Camly</h5>
                <small>CEO</small>
                <h6>Carlson Software</h6>
                <div class="m-t-15">
                    <button class="btn btn-sm btn-primary">View Profile</button>
                    <button class="btn btn-sm btn-success">Message</button>
                </div>
                <ul class="social-links list-unstyled">
                    <li><a title="google-plus"href="javascript:void(0);"><i class="fa fa-google-plus-box"></i></a></li>
                    <li><a title="twitter"href="javascript:void(0);"><i class="fa fa-twitter"></i></a></li>
                    <li><a title="linkedin"href="javascript:void(0);"><i class="fa fa-linkedin-box"></i></a></li>
                </ul>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-6 col-sm-12">
        <div class="card">
            <div class="body text-center">
                <div class="chart easy-pie-chart-1" data-percent="37"> <span><img src="../assets/images/sm/avatar2.jpg" alt="user" class="rounded-circle"/></span> </div>
                <h5>Gary Camara</h5>
                <small>Marketing Head</small>
                <h6>Fly2 Infotech</h6>
                <div class="m-t-15">
                    <button class="btn btn-sm btn-primary">View Profile</button>
                    <button class="btn btn-sm btn-success">Message</button>
                </div>
                <ul class="social-links list-unstyled">
                    <li><a title="facebook"href="javascript:void(0);"><i class="fa fa-facebook"></i></a></li>
                    <li><a title="twitter"href="javascript:void(0);"><i class="fa fa-twitter"></i></a></li>
                    <li><a title="instagram"href="javascript:void(0);"><i class="fa fa-instagram"></i></a></li>
                </ul>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-6 col-sm-12">
        <div class="card">
            <div class="body text-center">
                <div class="chart easy-pie-chart-1" data-percent="75"> <span><img src="../assets/images/sm/avatar5.jpg" alt="user" class="rounded-circle"/></span> </div>
                <h5>John Smith</h5>
                <small>Manager</small>
                <h6>puffintheme Pvt.</h6>
                <div class="m-t-15">
                    <button class="btn btn-sm btn-primary">View Profile</button>
                    <button class="btn btn-sm btn-success">Message</button>
                </div>
                <ul class="social-links list-unstyled">
                    <li><a title="facebook"href="javascript:void(0);"><i class="fa fa-facebook"></i></a></li>
                    <li><a title="twitter"href="javascript:void(0);"><i class="fa fa-twitter"></i></a></li>
                    <li><a title="instagram"href="javascript:void(0);"><i class="fa fa-instagram"></i></a></li>
                </ul>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>
<script src="<?php echo e(asset('assets/bundles/easypiechart.bundle.js')); ?>"></script>
<script src="<?php echo e(asset('assets/bundles/mainscripts.bundle.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>