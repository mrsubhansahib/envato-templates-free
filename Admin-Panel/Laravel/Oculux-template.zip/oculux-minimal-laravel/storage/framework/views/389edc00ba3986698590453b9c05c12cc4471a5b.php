<?php $__env->startSection('parentPageTitle', 'Pages'); ?>
<?php $__env->startSection('title', 'Gallery'); ?>


<?php $__env->startSection('content'); ?>
<div class="row clearfix">
    <div class="col-lg-12">
        <div class="card">
            <div class="header">
                <h2>Bootstrap 4 Gallery With Lightbox <small>All pictures taken from pexels.com</small></h2>
                <ul class="header-dropdown">
                    <li class="dropdown">
                        <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"></a>
                        <ul class="dropdown-menu dropdown-menu-right animated bounceIn">
                            <li><a href="javascript:void(0);">Action</a></li>
                            <li><a href="javascript:void(0);">Another Action</a></li>
                            <li><a href="javascript:void(0);">Something else</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
            <div class="body">
                <div class="gallery b4gallery" style="display:none;">
                    <img data-gallery-tag="tabe1" class="gallery-item" src="../assets/images/image-gallery/1.jpg" alt="" />
                    <div class="gallery-item h-100">
                        <div class="bg-danger d-flex flex-column text-warning justify-content-center align-items-center h-100 w-100 p-3">
                            <p class="lead m-0">I have no tag!</p>
                        </div>
                    </div>
                    <img data-gallery-tag="tabe2" class="gallery-item" src="../assets/images/image-gallery/2.jpg" alt="" />
                    <img data-gallery-tag="tabe3" class="gallery-item" src="../assets/images/image-gallery/3.jpg" alt="" />
                    <img data-gallery-tag="tabe2" class="gallery-item" src="../assets/images/image-gallery/4.jpg" alt="" />
                    <img data-gallery-tag="tabe4" class="gallery-item" src="../assets/images/image-gallery/5.jpg" alt="" />
                    <img data-gallery-tag="tabe1" class="gallery-item" src="../assets/images/image-gallery/6.jpg" alt="" />
                    <img data-gallery-tag="tabe4" class="gallery-item" src="../assets/images/image-gallery/7.jpg" alt="" />
                    <div class="gallery-item h-100">
                        <div class="bg-warning d-flex flex-column text-dark justify-content-center align-items-center h-100 w-100 p-3">
                            <p class="lead m-0">You can't filter me!</p>
                        </div>
                    </div>
                    <img data-gallery-tag="tabe1" class="gallery-item" src="../assets/images/image-gallery/8.jpg" alt="" />
                    <img data-gallery-tag="tabe3" class="gallery-item" src="../assets/images/image-gallery/9.jpg" alt="" />
                    <img data-gallery-tag="tabe2" class="gallery-item" src="../assets/images/image-gallery/10.jpg" alt="" />
                    <img data-gallery-tag="tabe1" class="gallery-item" src="../assets/images/image-gallery/11.jpg" alt="" />
                    <img data-gallery-tag="tabe3" class="gallery-item" src="../assets/images/image-gallery/12.jpg" alt="" />
                    <img data-gallery-tag="tabe4" class="gallery-item" src="../assets/images/image-gallery/13.jpg" alt="" />
                        <div class="gallery-item h-100">
                            <div class="bg-info d-flex flex-column text-warning justify-content-center align-items-center h-100 w-100 p-3">
                                <p class="lead m-0">Me neigher.</p>
                            </div>
                        </div>
                    <img data-gallery-tag="tabe1" class="gallery-item" src="../assets/images/image-gallery/14.jpg" alt="" />
                    <img data-gallery-tag="tabe4" class="gallery-item" src="../assets/images/image-gallery/15.jpg" alt="" />
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>
<script src="<?php echo e(asset('assets/bundles/mainscripts.bundle.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/LightboxGallery/mauGallery.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/LightboxGallery/scripts.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>