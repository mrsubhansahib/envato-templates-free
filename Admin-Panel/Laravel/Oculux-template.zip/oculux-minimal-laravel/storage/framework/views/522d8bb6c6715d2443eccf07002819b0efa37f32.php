<?php $__env->startSection('title', 'Page 503'); ?>

<?php $__env->startSection('content'); ?>
<div class="vertical-align-wrap">
    <div class="vertical-align-middle auth-main">
        <div class="auth-box">
            <div class="top">
                <img src="../assets/images/logo-white.svg" alt="Lucid">
            </div>
            <div class="card">
                <div class="header">
                    <h3>
                        <span class="clearfix title">
                            <span class="number">Error 5<i class="fa fa-smile-o"></i>3 </span> <br>
                            <span>Please try after some time</span>
                        </span>
                    </h3>
                </div>
                <div class="body">
                    <p>This site is getting up in few minutes.</p>
                    <p><a href="<?php echo e(route('dashboard.index')); ?>" class="btn btn-primary"><i class="fa fa-home"></i> <span>Home</span></a></p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.authentication', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>