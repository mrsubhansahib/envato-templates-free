<?php $__env->startSection('title', 'Expenses'); ?>
<?php $__env->startSection('parentPageTitle', 'Accounts'); ?>


<?php $__env->startSection('content'); ?>
<div class="row clearfix">
    <div class="col-lg-12">
        <div class="card">
            <div class="body">
                <div class="table-responsive">
                    <table class="table table-hover js-basic-example dataTable table-custom">
                        <thead>
                            <tr>
                                <th>Item</th>
                                <th>Order by</th>
                                <th>From</th>
                                <th>Date</th>
                                <th>Paid By</th>
                                <th>Status</th>
                                <th>Amount</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>HP Computer</td>
                                <td>Marshall Nichols</td>
                                <td>Amazon</td>
                                <td>07 March, 2018</td>
                                <td><img src="../assets/images/paypal.png" class="rounded width45" alt="paypal"></td>
                                <td><span class="badge badge-warning">Pending</span></td>
                                <td>$205</td>
                            </tr>
                            <tr>
                                <td>MacBook Pro</td>
                                <td>Debra Stewart</td>
                                <td>Amazon</td>
                                <td>17 Jun, 2018</td>
                                <td><img src="../assets/images/mastercard.png" class="rounded width45" alt="paypal"></td>
                                <td><span class="badge badge-success">Approved</span></td>
                                <td>$800</td>
                            </tr>
                            <tr>
                                <td>Dell Monitor 22 inch</td>
                                <td>Ava Alexander</td>
                                <td>Flipkart India</td>
                                <td>21 Jun, 2018</td>
                                <td><img src="../assets/images/mastercard.png" class="rounded width45" alt="paypal"></td>
                                <td><span class="badge badge-success">Approved</span></td>
                                <td>$205</td>
                            </tr>
                            <tr>
                                <td>Zebronics Desktop</td>
                                <td>Marshall Nichols</td>
                                <td>ebay UK</td>
                                <td>22 July, 2018</td>
                                <td><img src="../assets/images/paypal.png" class="rounded width45" alt="paypal"></td>
                                <td><span class="badge badge-warning">Pending</span></td>
                                <td>$355</td>
                            </tr>
                            <tr>
                                <td>Logitech USB Mouse, Keyboard</td>
                                <td>Marshall Nichols</td>
                                <td>Amazon</td>
                                <td>28 July, 2018</td>
                                <td><img src="../assets/images/paypal.png" class="rounded width45" alt="paypal"></td>
                                <td><span class="badge badge-success">Approved</span></td>
                                <td>$40</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>
<script src="<?php echo e(asset('assets/bundles/datatablescripts.bundle.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/pages/tables/jquery-datatable.js')); ?>"></script>

<script src="<?php echo e(asset('assets/bundles/mainscripts.bundle.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>