<?php $__env->startSection('parentPageTitle', 'Ui Elements'); ?>
<?php $__env->startSection('title', 'Colors'); ?>


<?php $__env->startSection('content'); ?>
<div class="row clearfix">
    <div class="col-lg-6 col-md-12">
        <div class="card">
            <div class="header">
                <h2>Colors</h2>
            </div>
            <div class="body">
                <p class="text-primary">.text-primary</p>
                <p class="text-secondary">.text-secondary</p>
                <p class="text-success">.text-success</p>
                <p class="text-danger">.text-danger</p>
                <p class="text-warning">.text-warning</p>
                <p class="text-info">.text-info</p>
                <p class="text-light bg-dark">.text-light</p>
                <p class="text-dark">.text-dark</p>
                <p class="text-body">.text-body</p>
                <p class="text-muted">.text-muted</p>
                <p class="text-white bg-dark">.text-white</p>
                <p class="text-black-50">.text-black-50</p>
                <p class="text-white-50 bg-dark">.text-white-50</p>
            </div>
        </div>
    </div>
    <div class="col-lg-6 col-md-12">
        <div class="card">
            <div class="header">
                <h2>Contextual text Colors</h2>
            </div>
            <div class="body">
                <p>classes also work well on anchors with the provided hover and focus states. <strong>Note that the <code class="highlighter-rouge">.text-white</code> and <code class="highlighter-rouge">.text-muted</code> class has no link styling.</strong></p>
                <p><a href="javascript:void(0);" class="text-primary">Primary link</a></p>
                <p><a href="javascript:void(0);" class="text-secondary">Secondary link</a></p>
                <p><a href="javascript:void(0);" class="text-success">Success link</a></p>
                <p><a href="javascript:void(0);" class="text-danger">Danger link</a></p>
                <p><a href="javascript:void(0);" class="text-warning">Warning link</a></p>
                <p><a href="javascript:void(0);" class="text-info">Info link</a></p>
                <p><a href="javascript:void(0);" class="text-light bg-dark">Light link</a></p>
                <p><a href="javascript:void(0);" class="text-dark">Dark link</a></p>
                <p><a href="javascript:void(0);" class="text-muted">Muted link</a></p>
                <p><a href="javascript:void(0);" class="text-white bg-dark">White link</a></p>
            </div>
        </div>
    </div>
</div>

<div class="row clearfix">
    <div class="col-lg-12 col-md-12">
        <div class="card">
            <div class="header">
                <h2>Background color</h2>
            </div>
            <div class="body">
                <p>Similar to the contextual text color classes, easily set the background of an element to any contextual class. Anchor components will darken on hover, just like the text classes. Background utilities <strong>do not set <code class="highlighter-rouge">color</code></strong>, so in some cases you’ll want to use <code class="highlighter-rouge">.text-*</code> utilities.</p>
                <div class="p-3 mb-2 bg-primary text-white">.bg-primary</div>
                <div class="p-3 mb-2 bg-secondary text-white">.bg-secondary</div>
                <div class="p-3 mb-2 bg-success text-white">.bg-success</div>
                <div class="p-3 mb-2 bg-danger text-white">.bg-danger</div>
                <div class="p-3 mb-2 bg-warning text-dark">.bg-warning</div>
                <div class="p-3 mb-2 bg-info text-white">.bg-info</div>
                <div class="p-3 mb-2 bg-light text-dark">.bg-light</div>
                <div class="p-3 mb-2 bg-dark text-white">.bg-dark</div>
                <div class="p-3 mb-2 bg-white text-dark">.bg-white</div>
                <div class="p-3 mb-2 bg-transparent text-dark">.bg-transparent</div>
            </div>
        </div>
    </div>
    <div class="col-lg-12 col-md-12">
        <div class="card">
            <div class="header">
                <h2>Background gradient color</h2>
            </div>
            <div class="body">
                <div class="row">
                    <div class="col-lg-3 col-md-4 col-sm-6"><div class="p-4 mb-2 l-green text-dark">.l-green</div></div>
                    <div class="col-lg-3 col-md-4 col-sm-6"><div class="p-4 mb-2 l-pink text-dark">.l-pink</div></div>
                    <div class="col-lg-3 col-md-4 col-sm-6"><div class="p-4 mb-2 l-turquoise text-white">.l-turquoise</div></div>
                    <div class="col-lg-3 col-md-4 col-sm-6"><div class="p-4 mb-2 l-khaki text-dark">.l-khaki</div></div>
                    <div class="col-lg-3 col-md-4 col-sm-6"><div class="p-4 mb-2 l-coral text-dark">.l-coral</div></div>
                    <div class="col-lg-3 col-md-4 col-sm-6"><div class="p-4 mb-2 l-blue text-dark">.l-blue</div></div>
                    <div class="col-lg-3 col-md-4 col-sm-6"><div class="p-4 mb-2 l-salmon text-white">.l-salmon</div></div>                                
                    <div class="col-lg-3 col-md-4 col-sm-6"><div class="p-4 mb-2 l-seagreen text-dark">.l-seagreen</div></div>
                    <div class="col-lg-3 col-md-4 col-sm-6"><div class="p-4 mb-2 l-amber text-white">.l-amber</div></div>
                    <div class="col-lg-3 col-md-4 col-sm-6"><div class="p-4 mb-2 l-blush text-white">.l-blush</div></div>
                    <div class="col-lg-3 col-md-4 col-sm-6"><div class="p-4 mb-2 l-parpl text-white">.l-parpl</div></div>
                    <div class="col-lg-3 col-md-4 col-sm-6"><div class="p-4 mb-2 l-slategray text-white">.l-slategray</div></div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-styles'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>
<script src="<?php echo e(asset('assets/bundles/mainscripts.bundle.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>