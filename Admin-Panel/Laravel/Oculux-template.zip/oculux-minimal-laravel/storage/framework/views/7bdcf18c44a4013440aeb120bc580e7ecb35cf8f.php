<?php $__env->startSection('title', 'Lockscreen'); ?>

<?php $__env->startSection('content'); ?>
<div class="vertical-align-wrap">
    <div class="vertical-align-middle auth-main">
        <div class="auth-box">
            <div class="top">
                <img src="../assets/images/logo-white.svg" alt="Lucid">
            </div>
            <div class="card">
                <div class="body">
                    <div class="user text-center m-b-30">
                        <img src="../assets/images/user-small.png" class="rounded-circle" alt="Avatar">
                        <h4 class="name m-t-10">Jessica Doe</h4>
                        <p>info@example.com</p>
                    </div>
                    <form action="index.html">
                        <div class="form-group">
                            <input type="password" class="form-control" placeholder="Enter your password ...">                                    
                        </div>
                        <a href="<?php echo e(route('dashboard.index')); ?>" class="btn btn-primary btn-lg btn-block">Login</a>                                
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.authentication', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>